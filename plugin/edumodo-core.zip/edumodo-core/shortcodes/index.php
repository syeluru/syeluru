<?php

# Silence of gold.