<?php
/*
Plugin Name: Edumodo Core
Description: Huge collection of custom widgets, neatly bundled into a single plugin. It's also a framework to code your own widgets to help you make any kind of page.
Version: 1.4
Text Domain: edumodo
Domain Path: edumodo/languages
Author: ThemeXpert
Author URI: https://www.themexpert.com
Plugin URI: https://www.themexpert.com/wordpress-plugins
License: GPL3
License URI: https://www.gnu.org/licenses/gpl-3.0.txt
*/

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

/**
 *
 * Plugin DocRoot absolute path without trailing slash
 *
 */

define('EDUMODO_BUNDLE_BASE_FILE', __FILE__);
define( 'EDUMODO_CORE_ROOT', untrailingslashit( plugin_dir_path( __FILE__ ) ) );



// helper functions
require_once EDUMODO_CORE_ROOT . '/elements/helper-functions.php';


/**
 * Load plugin
 *
 * Load the text domain and hook up the CPTs
 *
 */

function edumodo_core_load() {

    // Let's add some CPTs
    Edumodo_CPT_Course::init();
    Edumodo_CPT_Teacher::init();
    Edumodo_CPT_Notice::init();
    Edumodo_CPT_Testimonial::init();

    // Let's add some sohrtcode
    Edumodo_Shortcode_Course_Info::init();
    Edumodo_Shortcode_Testimonial::init();
    Edumodo_Shortcode_Related_Posts::init();
    Edumodo_Shortcode_Recent_Post::init();
    Edumodo_Shortcode_Course_Teacher::init();
    Edumodo_Shortcode_Course_Enroll::init();
    Edumodo_Shortcode_Follow_Us::init();
    Edumodo_Shortcode_QuickInfo::init();
    Edumodo_Shortcode_Mailchimp::init();


}

add_action( 'plugins_loaded', 'edumodo_core_load' );

	
/**
 *
 * Meta boxes
 *
 */

// Edumodo metabox
require_once EDUMODO_CORE_ROOT . '/metaboxes/edumodo-metabox.php';
// Page metabox
require_once EDUMODO_CORE_ROOT . '/metaboxes/edumodo-page-metabox.php';
// Event Metabox
require_once EDUMODO_CORE_ROOT . '/metaboxes/edumodo-event-metabox.php';
// Attached posts for course teacher
require_once EDUMODO_CORE_ROOT . '/libs/cmb2-attached-posts/cmb2-attached-posts-field.php';
// Blog Post Metabox
require_once EDUMODO_CORE_ROOT . '/libs/cmb2-conditionals/cmb2-conditionals.php';
require_once EDUMODO_CORE_ROOT . '/metaboxes/edumodo-blog-post-metabox.php';
				
/**
 *
 * Post types
 *
 */

// Course post types
require_once EDUMODO_CORE_ROOT . '/post-types/custom-course.php';
// Teachers post types
require_once EDUMODO_CORE_ROOT . '/post-types/custom-teacher.php';
// Notice post types
require_once EDUMODO_CORE_ROOT . '/post-types/custom-notice.php';
// Testimonial post types
require_once EDUMODO_CORE_ROOT . '/post-types/custom-testimonial.php';

/**
 *
 *  Shortcode
 *
 */

require_once EDUMODO_CORE_ROOT . '/shortcodes/shortcode-course-info.php';
require_once EDUMODO_CORE_ROOT . '/shortcodes/shortcode-testimonial.php';
require_once EDUMODO_CORE_ROOT . '/shortcodes/shortcode-related-posts.php';
require_once EDUMODO_CORE_ROOT . '/shortcodes/shortcode-recent-post.php';
require_once EDUMODO_CORE_ROOT . '/shortcodes/shortcode-course-teacher.php';
require_once EDUMODO_CORE_ROOT . '/shortcodes/shortcode-enroll-btn.php';
require_once EDUMODO_CORE_ROOT . '/shortcodes/shortcode-follow-us.php';
require_once EDUMODO_CORE_ROOT . '/shortcodes/shortcode-quick-info.php';
require_once EDUMODO_CORE_ROOT . '/shortcodes/shortcode-mailchimp.php';

                        
/**
 *
 *  Custom Widgets
 *
 */

// Recent Posts
require_once EDUMODO_CORE_ROOT . '/widget/recent-post.php';

                       
/**
 *
 *  Elemontor elements
 *
 */

// Slider elements
require_once EDUMODO_CORE_ROOT . '/elements/slider/plugin.php';
// require_once EDUMODO_CORE_ROOT . '/elements/slider-sensei/plugin.php';

// Custom course elements
require_once EDUMODO_CORE_ROOT . '/elements/course-1/plugin.php';

// Custom teachers elements
require_once EDUMODO_CORE_ROOT . '/elements/teacher-1/plugin.php';
require_once EDUMODO_CORE_ROOT . '/elements/teacher-2/plugin.php';

// Custom notice elements
require_once EDUMODO_CORE_ROOT . '/elements/notice-1/plugin.php';

// Event calender elements
require_once EDUMODO_CORE_ROOT . '/elements/event/plugin.php';
require_once EDUMODO_CORE_ROOT . '/elements/event-two/plugin.php';

// Woocommerce Letest product elements
require_once EDUMODO_CORE_ROOT . '/elements/woo-latest-product/plugin.php';

// Learnpress Course elements
require_once EDUMODO_CORE_ROOT . '/elements/learnpress-course/plugin.php';
// Sensei Course elements
require_once EDUMODO_CORE_ROOT . '/elements/sensei-course/plugin.php';

// Learnpress Course Categories elements
require_once EDUMODO_CORE_ROOT . '/elements/learnpress-categories/plugin.php';


// Sensei Course Categories elements
require_once EDUMODO_CORE_ROOT . '/elements/sensei-categories/plugin.php';

// Latest Articles Categories elements
require_once EDUMODO_CORE_ROOT . '/elements/latest-post/plugin.php';
require_once EDUMODO_CORE_ROOT . '/elements/testimonial-1/plugin.php';


/**
 * Load the javascript
 * That is depends on shortcode or metabox
 */
add_action( 'elementor/frontend/after_register_scripts', function() {
    //wp_register_script( 'demo', plugins_url( '/assets/js/demo/demo.js', __FILE__ ), array('jquery'), false, true );
    wp_register_script( 'imagesloaded', plugins_url( '/assets/js/imagesloaded.js', __FILE__ ), array('jquery'), false, true );
    //wp_register_script( 'anime', plugins_url( '/assets/js/anime.min.js', __FILE__ ), array('jquery'), false, true );
   // wp_register_script( 'demo1', plugins_url( '/assets/js/demo/demo1.js', __FILE__ ), array('jquery'), false, true );
} );

// add_action( 'elementor/widget/render_content', function( $content, $widget ) {
//     if ( 'edumodo-slider-sendei' === $widget->get_name() ) {
//         wp_enqueue_style('base', plugin_dir_url(__FILE__) . 'assets/css/base.css');
//         wp_enqueue_style('pater', plugin_dir_url(__FILE__) . 'assets/css/pater.css');
//     }
//     return $content;
// }, 10, 2 );

