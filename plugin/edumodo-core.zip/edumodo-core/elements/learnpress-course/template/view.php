<?php
    $settings = $this->get_settings();
    global $post;
    $prefix = '_edumodo_';
    $show_hide_lp_instructor = $settings['show_hide_lp_instructor'];
    $excerpt_title_word = $settings['excerpt_title_word'];
    $excerpt_desc_word = $settings['excerpt_desc_word'];
    $lp_course_price_top = $settings['lp_course_price_top'];

?>
<?php if ($settings['lp_course_style'] == 'style_1') : ?>
    <div class="edumodo-lp-course-1">
         <div class="row">
                <?php
                    $course = array(
                        'post_type'         => 'lp_course',
                        'posts_per_page'    => $settings['posts_per_page']

                    );

                    $course_query = new WP_Query( $course );
                        if($course_query->have_posts()):
                            while($course_query->have_posts()): 
                                $course_query->the_post(); 
                ?>

                <div class="course-content-wrapper col-md-<?php echo $settings['posts_column']; ?>">
                    <article id="post-<?php the_ID(); ?>" <?php post_class('lp-course-1'); ?>>

                        <?php if ( has_post_thumbnail() ):?>
                            <figure class="lp-course-thumbnail">
                               <div class="lp-img">
                                    <a href="<?php the_permalink(); ?>">
                                        <?php  the_post_thumbnail();?>
                                    </a>
                        <?php
                            $lp_course_price_top = $settings['lp_course_price_top'];
                            if($lp_course_price_top == 'yes'): ?>

                                 <?php $course = LP_Global::course();?>
                                    <div class="addon-price-wapper">
                                        <?php if ( $price_html = $course->get_price_html() ) { ?>

                                            <?php if ( $course->get_origin_price() != $course->get_price() ) { ?>

                                                <?php $origin_price_html = $course->get_origin_price_html(); ?>
                                                <span class="addon-origin-price"><?php echo $origin_price_html; ?></span>

                                            <?php } ?>

                                            <span class="addon-price"><?php echo $price_html; ?></span>
                                    </div>
                                    <?php } 

                            endif; ?>

                               </div>
                            <?php if($show_hide_lp_instructor == 'yes'): ?>
                                <div class="author-wrapper">
                                    <div class="tx-author-img"><?php echo get_avatar( get_the_author_meta( 'ID' ), 50 ); ?></div>
                                </div>
                            <?php endif; ?>
                            </figure>

                        <?php endif; ?>

                        <div class="course-content-body">

                            <header class="entry-header">
                                <h4 class="course-entry-title">
                                    <a href="<?php the_permalink();?>">
                                        <?php esc_html_e(wp_trim_words( get_the_title(),  $excerpt_title_word, ''), 'edumodo'); ?>                         
                                    </a>
                                </h4>       
                            </header>

                            <?php if ($course_query):?>
                                <div class="entry-content">
                                    <p><?php esc_html_e(wp_trim_words( get_the_content(), $excerpt_desc_word, ''), 'edumodo'); ?></p>
                                </div>
                            <?php endif; ?>

                          
                            <div class="course-meta addons-course-meta">

                                    <?php

                                    $lp_course_price = $settings['lp_course_price'];
                                    if($lp_course_price == 'yes'): ?>

                                         <?php $course = LP_Global::course();?>

                                            <?php if ( $price_html = $course->get_price_html() ) { ?>

                                                <?php if ( $course->get_origin_price() != $course->get_price() ) { ?>

                                                    <?php $origin_price_html = $course->get_origin_price_html(); ?>
                                                    <span class="addon-origin-price"><?php echo $origin_price_html; ?></span>

                                                <?php } ?>

                                                <span class="addon-price"><?php echo $price_html; ?></span>

                                            <?php } 

                                        endif; ?>
                                           
                                    <?php
                                        $lp_course_cat = $settings['lp_course_cat'];
                                        if($lp_course_cat == 'yes'): ?>

                                            <span class="post-date">
                                                <i class="fa fa-folder-open" aria-hidden="true"></i><?php learn_press_course_categories(); ?>
                                            </span>

                                        <?php endif; ?>
                                    <?php
                                        $lp_course_students_er = $settings['lp_course_students_er'];
                                        if($lp_course_students_er == 'yes'): ?>
                                            <?php  $lp_students = get_post_meta(get_the_ID(), '_lp_students'); ?>
                                            <span class="post-view">
                                                <i class="fa fa-users" aria-hidden="true"></i><?php echo esc_html($lp_students[0]);  ?>
                                            </span>
                                    <?php endif; ?>

                                    <?php
                                        $lp_course_lessons = $settings['lp_course_lessons'];
                                        if($lp_course_lessons == 'yes'): ?>
                                            <span class="post-view">
                                                <i class="fa fa-book" aria-hidden="true"></i><?php echo esc_html($lp_students[0]);  ?>
                                            </span>
                                    <?php endif; ?>

                            </div>
                        </div>

                    </article>
                </div>
            <?php endwhile; wp_reset_postdata(); endif; ?>
        </div> 
    </div> 
<?php elseif($settings['lp_course_style'] == 'style_2') : ?>
    <div class="edumodo-course-1">
         <div class="row">
                <?php
                        $course = array(
                            'post_type'         => 'lp_course',
                            'posts_per_page'    => $settings['posts_per_page']
                        );

                    $course_query = new WP_Query( $course );
                        if($course_query->have_posts()):
                            while($course_query->have_posts()): 
                                $course_query->the_post(); 
                ?>

                <div class="col-md-<?php echo $settings['posts_column']; ?>">
                    <article  class="tx-course">
                        <?php if ( has_post_thumbnail() ):?>
                            <figure class="post-thumbnail">
                                <a href="<?php the_permalink(); ?>">
                                    <?php  the_post_thumbnail();?>
                                </a>
                            </figure>
                        <?php endif; ?>

                        <div class="course-details">
                            <header class="entry-header">
                                <h4 class="course-entry-title">
                                    <a href="<?php the_permalink();?>">
                                        <?php esc_html_e(wp_trim_words( get_the_title(), $excerpt_title_word, ''), 'edumodo'); ?>                                   
                                    </a>
                                </h4>       
                            </header>

                            <div class="course-meta addons-course-meta">

                                    <?php

                                    $lp_course_price = $settings['lp_course_price'];
                                    if($lp_course_price == 'yes'): ?>

                                         <?php $course = LP_Global::course();?>

                                            <?php if ( $price_html = $course->get_price_html() ) { ?>

                                                <?php if ( $course->get_origin_price() != $course->get_price() ) { ?>

                                                    <?php $origin_price_html = $course->get_origin_price_html(); ?>
                                                    <span class="addon-origin-price"><?php echo $origin_price_html; ?></span>

                                                <?php } ?>

                                                <span class="addon-price"><?php echo $price_html; ?></span>

                                            <?php } 

                                        endif; ?>
                                           
                                    <?php
                                        $lp_course_cat = $settings['lp_course_cat'];
                                        if($lp_course_cat == 'yes'): ?>

                                            <span class="post-date">
                                                <i class="fa fa-folder-open" aria-hidden="true"></i><?php learn_press_course_categories(); ?>
                                            </span>

                                        <?php endif; ?>
                                    <?php
                                        $lp_course_students_er = $settings['lp_course_students_er'];
                                        if($lp_course_students_er == 'yes'): ?>
                                            <?php  $lp_students = get_post_meta(get_the_ID(), '_lp_students'); ?>
                                            <span class="post-view">
                                                <i class="fa fa-users" aria-hidden="true"></i><?php echo esc_html($lp_students[0]);  ?>
                                            </span>
                                    <?php endif; ?>

                                    <?php
                                        $lp_course_lessons = $settings['lp_course_lessons'];
                                        if($lp_course_lessons == 'yes'): ?>
                                            <span class="post-view">
                                                <i class="fa fa-book" aria-hidden="true"></i><?php echo esc_html($lp_students[0]);  ?>
                                            </span>
                                    <?php endif; ?>

                            </div>

                            <div class="entry-content">
                                <p><?php esc_html_e(wp_trim_words( get_the_content(), $excerpt_desc_word, ''), 'edumodo'); ?></p>
                            </div>
                        </div>
                    </article>
                </div>

            <?php endwhile; wp_reset_postdata(); endif; ?>
        </div>  
    </div> 
<?php endif; ?>