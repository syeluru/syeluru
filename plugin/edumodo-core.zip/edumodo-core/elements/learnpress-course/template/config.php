<?php


use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Typography;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Edumodo course
 *
 * Elementor widget for edumodo course
 *
 * @since 1.0.0
 */
class Edumodo_Learnpress_Course extends Widget_Base {

	public function get_name() {
		return 'edumodo-learnpress-course';
	}

	public function get_title() {
		return __( 'Learnpress Courses', 'edumodo' );
	}

	public function get_icon() {
		return 'eicon-sidebar';
	}

	public function get_categories() {
		return [ 'edumodo' ];
	}

	/**
	 * A list of scripts that the widgets is depended in
	 * @since 1.3.0
	 **/
	public function get_script_depends() {
		return [ 'edumodo-learnpress-course' ];
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'section_title',
			[
				'label' => __( 'Content', 'edumodo' ),
			]
		);

		$this->add_control(
			'lp_course_style',
			[
				'label'     => esc_html__( 'Course Style', 'hostzine' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'style_2',
				'options'   => [
					'style_1'   => esc_html__( 'Style 1', 'hostzine' ),
					'style_2'   => esc_html__( 'Style 2', 'hostzine' ),
				],

			]
		);

        $this->add_control(
            'posts_per_page',
            [
                'label' => __('Item to Show', 'edumodo'),
                'type' => Controls_Manager::NUMBER,
                'default' => 6,
                'min' => 1,
                'max' => 50,
                'step' => 1,
            ]
        );

        $this->add_control(
            'posts_column',
            [
                'label' => __('Column', 'edumodo'),
                'type' => Controls_Manager::SELECT,
                'default' => '4',
                'options' => [
                    '2' => __('6 Column', 'edumodo'),
                    '3' => __('4 Column', 'edumodo'),
                    '4' => __('3 Column', 'edumodo'),
                    '6' => __('2 Column', 'edumodo'),
                    '12' => __('1 Column', 'edumodo'),
                ],
            ]
        );

		$this->end_controls_section();

		$this->start_controls_section(
			'edumodo_section_title_typography',
			[
				'label' => __( 'Title', 'edumodo' ),
			]
		);

       	$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'edumodo_title_typography',
                'selector' => '{{WRAPPER}} .edumodo-lp-course-1 .lp-course-1 .course-content-body .course-entry-title a, .edumodo-course-1 article.tx-course .course-details .entry-header .course-entry-title',
                'scheme' => Scheme_Typography::TYPOGRAPHY_3,
            ]
        );

        $this->add_control(
            'excerpt_title_word',
            [
                'label' => __('Excerpt Title Word', 'edumodo'),
                'type' => Controls_Manager::NUMBER,
                'default' => 7,
                'min' => 1,
                'max' => 50,
                'step' => 1,
            ]
        );

		$this->end_controls_section();

		$this->start_controls_section(
			'section_meta',
			[
				'label' => __( 'Meta', 'edumodo' ),
			]
		);

        $this->add_control(
            'lp_course_price',
            [
                'label' => __( 'Show Price', 'edumodo' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'label_on' => __( 'Show', 'edumodo' ),
                'label_off' => __( 'Hide', 'edumodo' ),
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'lp_course_price_top',
            [
                'label' => __( 'Show Top Price', 'edumodo' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no',
                'label_on' => __( 'Show', 'edumodo' ),
                'label_off' => __( 'Hide', 'edumodo' ),
                'return_value' => 'yes',
                'condition' => [
                    'lp_course_style' => 'style_1',
                ],
            ]
        );
        
        $this->add_control(
            'lp_course_cat',
            [
                'label' => __( 'Show Categories', 'edumodo' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'label_on' => __( 'Show', 'edumodo' ),
                'label_off' => __( 'Hide', 'edumodo' ),
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'lp_course_students_er',
            [
                'label' => __( 'Show Enrolled', 'edumodo' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'label_on' => __( 'Show', 'edumodo' ),
                'label_off' => __( 'Hide', 'edumodo' ),
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'lp_course_lessons',
            [
                'label' => __( 'Show Lessons', 'edumodo' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no',
                'label_on' => __( 'Show', 'edumodo' ),
                'label_off' => __( 'Hide', 'edumodo' ),
                'return_value' => 'no',
            ]
        );

        $this->add_control(
            'show_hide_lp_instructor',
            [
                'label' => __( 'Show Instructor', 'edumodo' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'label_on' => __( 'Show', 'edumodo' ),
                'label_off' => __( 'Hide', 'edumodo' ),
                'return_value' => 'yes',
                'condition' => [
					'lp_course_style' => 'style_1',
				],
            ]

        );

		$this->end_controls_section();
		$this->start_controls_section(
			'section_desc_typography',
			[
				'label' => __( 'Description', 'edumodo' ),
			]
		);

       	$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'desc_typography',
                'selector' => '{{WRAPPER}} .edumodo-lp-course-1 .lp-course-1 .entry-content  p, .edumodo-course-1 article.tx-course .course-details .entry-content p',
                'scheme' => Scheme_Typography::TYPOGRAPHY_3,
            ]
        );

        $this->add_control(
            'excerpt_desc_word',
            [
                'label' => __('Excerpt Description Word', 'edumodo'),
                'type' => Controls_Manager::NUMBER,
                'default' => 15,
                'min' => 5,
                'max' => 150,
                'step' => 1,
            ]
        );

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style',
				[
					'label' => __( 'Color Options', 'edumodo' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				]
			);

		$this->add_control(
			'title_color',
			[
				'label'     => __( 'Title Color', 'edumodo' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#333',
				'selectors' => [
					'{{WRAPPER}} .edumodo-lp-course-1 .lp-course-1 .course-content-body .course-entry-title a, .edumodo-course-1 article.tx-course .course-details .entry-header .course-entry-title a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'meta_color',
			[
				'label'     => __( 'Meta Color', 'edumodo' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#808080',
				'selectors' => [
					'{{WRAPPER}} .edumodo-course-1 article.tx-course .course-details .course-meta .post-date a, .edumodo-course-1 article.tx-course .edumodo-course-1 article.tx-course .course-details .course-meta .post-view, .edumodo-course-1 article.tx-course .course-details .course-meta .post-date, .edumodo-course-1 article.tx-course .course-details .course-meta .post-view i, .edumodo-course-1 article.tx-course .course-details .course-meta .post-view, .edumodo-lp-course-1 span.cat-links a, .edumodo-lp-course-1 span.post-date, .edumodo-lp-course-1 span.post-view' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'desc_color',
			[
				'label'     => __( 'Content Color', 'edumodo' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#525c65',
				'selectors' => [
					'{{WRAPPER}} .edumodo-lp-course-1 .lp-course-1 .course-content-body .entry-content, .edumodo-course-1 article.tx-course .course-details .entry-content p' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

	}

	protected function render() {
		require EDUMODO_CORE_ROOT . '/elements/learnpress-course/template/view.php';
	}


}
