<?php
// Silence is golden.

    $settings = $this->get_settings();

    // Global Options
    global $post;
     // Prefix
    $prefix = '_edumodo_';

?>

    <section class="edumodo-teacher-1">
        <div class="row">
            <?php
                $teacher = array(
                    'post_type'         => 'teacher',
                    'post_status'       => 'publish',
                    'posts_per_page'    => $settings['posts_per_page'],
                );

                $teacher_query = new WP_Query( $teacher );
                    if($teacher_query->have_posts()):
                        while($teacher_query->have_posts()): 
                            $teacher_query->the_post(); 

                            $teacher_img_links = get_post_meta( $post->ID, $prefix . 'teacher_img', true );
                            $designation = get_post_meta( $post->ID, $prefix . 'teacher_designation', true );
                            $email = get_post_meta( $post->ID, $prefix . 'teacher_email', true );
                            $phone = get_post_meta( $post->ID, $prefix . 'teacher_phone', true );
                            $website = get_post_meta( $post->ID, $prefix . 'teacher_website', true );
                            $teacher_facebook = get_post_meta( $post->ID, $prefix . 'teacher_facebook_link', true );
                            $teacher_twitter = get_post_meta( $post->ID, $prefix . 'teacher_twitter_link', true );
                            $teacher_google_plus = get_post_meta( $post->ID, $prefix . 'teacher_google_plus_link', true );
                            $teacher_linkedin = get_post_meta( $post->ID, $prefix . 'teacher_linkedin_link', true );

            ?>

                <div class="col-md-<?php echo $settings['posts_column']; ?>">
                    <section class="teacher-2">
                        <div class="teacher-container">
                            <!-- First teacher Block -->
                            <div class="teacher-each-wrap">
                                <div class="teacher-block">
                                    <div class="teacher-image">                    
                                        <img src="<?php echo $teacher_img_links; ?>" alt="<?php the_title(); ?>">   
                                    </div>
                                        <div class="teacher-social">
                                          <?php if ($teacher_facebook) : ?>
                                                  <a class="teacher-facebook" href="<?php echo $teacher_facebook; ?>"><i class="fa fa-facebook"></i></a>
                                          <?php endif; ?>

                                          <?php if ($teacher_twitter) : ?>
                                                  <a class="teacher-twitter" href="<?php echo $teacher_twitter; ?>"><i class="fa fa-twitter"></i> </a>
                                          <?php endif; ?>

                                          <?php if ($teacher_google_plus) : ?>
                                                  <a class="teacher-gplus" href="<?php echo $teacher_google_plus; ?>"><i class="fa fa-google-plus-square"></i> </a>
                                          <?php endif; ?>

                                          <?php if ($teacher_linkedin) : ?>
                                                   <a class="teacher-linkedin" href="<?php echo $teacher_linkedin; ?>"><i class="fa fa-linkedin"></i> </a>
                                          <?php endif; ?>
                                        </div>  

                                <div class="teacher-info">
                                    <div class="name">
                                     <a href="<?php the_permalink(); ?>">
                                            <h4 class="teacher-title"><?php the_title(); ?></h4>
                                     </a>
                                        <?php if ( ! empty( $designation ) ) : ?>
                                            <span class="teacher-designation"><?php echo $designation; ?></span>
                                        <?php endif; ?>
                                    </div>
                   
                                    </div><!-- end .hover content -->           
                                </div>

                            </div><!-- end .teacher wrap -->
                        </div><!-- end .tema container -->
                    </section> <!-- end .section -->
                </div>
                
            <?php endwhile; wp_reset_postdata(); endif; ?>
        </div><!-- /.row -->     
    </section> <!-- /.section -->
