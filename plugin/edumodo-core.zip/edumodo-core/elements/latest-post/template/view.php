<?php
// Silence is golden.

    $settings = $this->get_settings();

    // Global Options
    global $post;
     // Prefix
    $prefix = '_edumodo_';

    $show_hide_post_author = $settings['show_hide_post_author'];
    $excerpt_word = $settings['latest_excerpt_word'];

?>

    <section class="edumodo-letest-posts">
         <div class="row">
                <?php
                    $blog = array(
                        'post_type'         => 'post',
                        'posts_per_page'    => $settings['posts_per_page'],
                        'ignore_sticky_posts' => 1
                    );

                    $blog_query = new WP_Query( $blog );
                        if($blog_query->have_posts()):
                            while($blog_query->have_posts()): 
                                $blog_query->the_post(); 
                ?>

                <div class="edumodo-blog-content-wrapper col-md-<?php echo $settings['posts_column']; ?>">
                    <article id="post-<?php the_ID(); ?>" <?php post_class('letest-posts-1'); ?>>


                            <figure class="post-thumbnail">
                                <a href="<?php the_permalink(); ?>">
                                    <?php  the_post_thumbnail();?>
                                </a>
                            </figure>

                        <div class="post-content-body">
                                
                            <header class="entry-header">
                                <div class="entry-meta">
                                  <?php if ($show_hide_post_author) : ?>
                                    <i class="fa fa-user" aria-hidden="true"></i><span class="post-author"><a href="<?php get_the_author_link(); ?>"><?php the_author(); ?></a></span>
                                <?php endif ?>
                                      <span class="post-date">
                                        <?php 
                                            $archive_year  = get_the_time('Y'); 
                                            $archive_month = get_the_time('m'); 
                                            $archive_day   = get_the_time('d'); 
                                        ?>
                                        <i class="fa fa-calendar" aria-hidden="true"></i><a href="<?php echo get_day_link( $archive_year, $archive_month, $archive_day); ?>"><?php echo get_the_date('M j, Y'); ?></a>   
                                    </span>
                                </div>
                                <h4 class="post-entry-title">
                                    <a href="<?php the_permalink();?>">
                                       <?php echo wp_trim_words( get_the_title(),7, ''); ?>      
                                    </a>
                                </h4>       
                            </header><!-- .entry-header -->

                                <div class="entry-content">
                                     <p><?php echo wp_trim_words(get_the_excerpt(), $excerpt_word , ''); ?></p>
                                </div><!-- .entry-content -->

                            <footer class="blog-entry-footer">
                                <span class="blog-btn">
                                    <a href="<?php the_permalink();?>"><?php esc_html_e('Read More', 'edumodo') ?><i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>   
                                </span>
                            </footer>
                        </div><!-- .blog details -->
               
                    </article><!-- #post-## -->
                </div> <!-- /.col-md-4 -->

            <?php endwhile; wp_reset_postdata(); endif; ?>
        </div><!-- /.row -->     
    </section> <!-- /.section -->
