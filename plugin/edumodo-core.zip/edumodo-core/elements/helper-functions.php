<?php
namespace Elementor;

function edumodo_elementor_init(){
    Plugin::instance()->elements_manager->add_category(
        'edumodo',
        [
            'title'  => __('Edumodo Elements', 'edumodo'),
            'icon'   => 'eicon-font'
        ],
        1
    );
}
add_action('elementor/init','Elementor\edumodo_elementor_init');


if (!function_exists('array_get')) {
    function array_get($array, $key, $default = null)
    {
        if (!is_array($array)) return $default;
        return array_key_exists($key, $array) ? $array[$key] : $default;
    }
}

add_filter( 'widget_text', 'do_shortcode' );
