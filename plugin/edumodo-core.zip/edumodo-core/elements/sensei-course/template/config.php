<?php


use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Typography;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Edumodo course
 *
 * Elementor widget for edumodo course
 *
 * @since 1.0.0
 */
class Edumodo_Widget_Sensei_Course extends Widget_Base {

	public function get_name() {
		return 'edumodo-sensei-course';
	}

	public function get_title() {
		return __( 'Sensei Courses', 'edumodo' );
	}

	public function get_icon() {
		return 'eicon-sidebar';
	}

	public function get_categories() {
		return [ 'edumodo' ];
	}

	/**
	 * A list of scripts that the widgets is depended in
	 * @since 1.3.0
	 **/

	protected function _register_controls() {

		$this->start_controls_section(
			'section_title',
			[
				'label' => __( 'Content', 'edumodo' ),
			]
		);

        $this->add_control(
            'posts_per_page',
            [
                'label' => __('Item to Show', 'edumodo'),
                'type' => Controls_Manager::NUMBER,
                'default' => 8,
                'min' => -1,
                'max' => 50,
                'step' => 1,
            ]
        );

        $this->add_control(
            'posts_column',
            [
                'label' => __('Column', 'edumodo'),
                'type' => Controls_Manager::SELECT,
                'default' => '3',
                'options' => [
                    '2' => __('6 Column', 'edumodo'),
                    '3' => __('4 Column', 'edumodo'),
                    '4' => __('3 Column', 'edumodo'),
                    '6' => __('2 Column', 'edumodo'),
                    '12' => __('1 Column', 'edumodo'),
                ],
            ]
        );

		$this->end_controls_section();

		$this->start_controls_section(
			'edumodo_section_title_typography',
			[
				'label' => __( 'Title', 'edumodo' ),
			]
		);

       	$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'edumodo_title_typography',
                'selector' => '{{WRAPPER}} .edumodo-lp-course-1 .lp-course-1 .course-content-body .course-entry-title a',
                'scheme' => Scheme_Typography::TYPOGRAPHY_3,
            ]
        );

		$this->end_controls_section();

		$this->start_controls_section(
			'section_meta',
			[
				'label' => __( 'Meta', 'edumodo' ),
			]
		);

       	$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'meta_title_typography',
                'selector' => '{{WRAPPER}} .edumodo-course-1 header a',
                'scheme' => Scheme_Typography::TYPOGRAPHY_3,
            ]
        );

        $this->add_control(
            'show_hide_lp_instructor',
            [
                'label' => __( 'Show Instructor', 'edumodo' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'label_on' => __( 'Show', 'edumodo' ),
                'label_off' => __( 'Hide', 'edumodo' ),
                'return_value' => 'yes',
            ]
        );

		$this->end_controls_section();

		$this->start_controls_section(
			'section_desc_typography',
			[
				'label' => __( 'Description', 'edumodo' ),
			]
		);

       	$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'desc_typography',
                'selector' => '{{WRAPPER}} .edumodo-lp-course-1 .entry-content  p',
                'scheme' => Scheme_Typography::TYPOGRAPHY_3,
            ]
        );

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style',
				[
					'label' => __( 'Color Options', 'edumodo' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				]
			);

		$this->add_control(
			'title_color',
			[
				'label'     => __( 'Title Color', 'edumodo' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#333',
				'selectors' => [
					'{{WRAPPER}} .edumodo-lp-course-1 .lp-course-1 .course-content-body .course-entry-title a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'meta_color',
			[
				'label'     => __( 'Meta Color', 'edumodo' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#7d97ad',
				'selectors' => [
					'{{WRAPPER}} .edumodo-lp-course-1 .lp-course-1 .course-content-body .footer-body span.lp-enroll ' => 'color: {{VALUE}};',
					'{{WRAPPER}} .edumodo-lp-course-1 .lp-course-1 .course-content-body .footer-body span.lp-enroll a' => 'color: {{VALUE}};',
					'{{WRAPPER}} .edumodo-lp-course-1 .lp-course-1 .course-content-body .footer-body span.lp-enroll i' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'desc_color',
			[
				'label'     => __( 'Content Color', 'edumodo' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#525c65',
				'selectors' => [
					'{{WRAPPER}} .edumodo-lp-course-1 .lp-course-1 .course-content-body .entry-content' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

	}

	protected function render() {
		require EDUMODO_CORE_ROOT . '/elements/sensei-course/template/view.php';
	}


}
