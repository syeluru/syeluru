<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Class Edumodo_Woo_latest_Product_Config
 */
class Edumodo_Woo_latest_Product_Config extends Widget_Base {

	public function get_name() {
		return 'edumodo-woo-latest-product';
	}

	public function get_title() {
		return __( 'Woo Latest Product', 'edumodo' );
	}

	public function get_icon() {
		return 'eicon-woocommerce';
	}

	public function get_categories() {
		return [ 'edumodo' ];
	}

	/**
	 * A list of scripts that the widgets is depended in
	 * @since 1.3.0
	 **/
//	public function get_script_depends() {
//		return [ 'edumodo-blog-1' ];
//	}

	protected function _register_controls() {
        $this->start_controls_section(
            'section_title',
            [
                'label' => __( 'Content', 'edumodo' ),
            ]
        );
        $this->add_control(
            'posts_per_page',
            [
                'label' => __('Item to Show', 'edumodo'),
                'type' => Controls_Manager::NUMBER,
                'default' => 3,
                'min' => 2,
                'max' => 4,
                'step' => 1,
            ]
        );
        $this->add_control(
            'title_word',
            [
                'label' => __('Title Word', 'edumodo'),
                'type' => Controls_Manager::NUMBER,
                'default' => 4,
                'min' => 1,
                'max' => 20,
                'step' => 1,
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'section_style',
            [
                'label' => __( 'Color Options', 'edumodo' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'title_color',
            [
                'label'     => __( 'Title Color', 'edumodo' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#333',
                'selectors' => [
                    '{{WRAPPER}} .e-woo-latest-product  a.edumodo-title' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'author_color',
            [
                'label'     => __( 'Author Color', 'edumodo' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#666',
                'selectors' => [
                    '{{WRAPPER}} .e-woo-latest-product .e-product-author' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->end_controls_section();
    }

	protected function render() {
        $settings = $this->get_settings();
        $number_of_product = $settings['posts_per_page'];
        $title_word = $settings['title_word'];
        $column_number = 12 / $number_of_product;

        $args = array(
            'post_type' => 'product',
            'stock' => 1,
            'posts_per_page' => $number_of_product,
            'orderby' =>'date',
            'order' => 'DESC'
        );

        $query = new WP_Query($args);


        if($query->have_posts()):
            ?>
            <div class="e-woo-latest-product">
            <ul class="product">
            <?php
            while($query->have_posts()):

                $query->the_post();


                ?>
                <li class="product-item col-md-<?php echo $column_number ;?>">
                    <?php
                    $product_author = get_post_meta(get_the_ID(), '_edumodo_product_author');
                    ?>
                    <div class="e.product-item-wrapper">
                        <figure>
                            <div class="product-image">
                                <a href="<?php the_permalink(); ?>" >
                                    <div class="atvImg e-atvImg">
                                    <?php if(has_post_thumbnail()): ?>
                                        <?php the_post_thumbnail('full'); ?>
                                    <?php endif; ?>
                                    <div class="atvImg-layer" data-img="<?php echo get_the_post_thumbnail_url(get_the_ID()); ?>"></div>
                                    <div class="atvImg-layer" data-img="<?php echo get_the_post_thumbnail_url(get_the_ID()); ?>"></div>
                                    </div>
                                </a>

                            </div>
                        </figure>

                        <div class="product-short-info">

                            <a class="edumodo-title e-product-title" href="<?php the_permalink();?>">
                                <?php the_title(); ?>
                            </a>
                            <?php //var_dump($product_author); ?>
                            <?php if(! empty($product_author[0])): ?>
                            <p class="e-product-author">
                                <span><?php esc_html_e('By ', 'edumodo'); ?></span>
                                <span><?php echo $product_author[0]; ?></span>
                            </p>
                            <?php endif; ?>
                            <div class="e-product-price">
                                <div class="e-product-price-wrapper">
                                    <?php echo do_shortcode('[add_to_cart id="'. get_the_ID() .'"]'); ?>
                                </div>
                            </div>

                        </div>
                    </div>
                </li>

                <?php
            endwhile;
            ?>
            </ul>
            </div>
            <?php
            wp_reset_postdata();
        endif;
	}
}
