<?php

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Repeater;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Typography;

if (!defined('ABSPATH')) exit; // Exit if accessed directly

/**
 * edumodo Schedule One
 *
 * Elementor widget for Schedule One.
 *
 * @since 1.0.0
 */
class Widget_Slider_Sensei extends Widget_Base
{

    public function get_name()
    {
        return 'edumodo-slider-sendei';
    }

    public function get_title()
    {
        return __('Slider Sensei', 'edumodo');
    }

    public function get_icon()
    {
        return 'eicon-post-slider';
    }

    public function get_categories()
    {
        return ['edumodo'];
    }

    /**
     * A list of scripts that the widgets is depended in
     *
     * @since 1.3.0
     **/
    public function get_script_depends() {
        return [ 'demo', 'imagesloaded', 'anime', 'demo1'];
    }

    protected function _register_controls()
    {
        /* slides content title subtitle button and button link */
        $this->start_controls_section(
            'section_tab',
            [
                'label' => __('Slides', 'edumodo'),
            ]
        );
            $repeater = new Repeater();
            $repeater->add_control(
                'slide_image',
                [
                    'name' => 'slide_image',
                    'label' => __( 'Choose Image', 'edumodo' ),
                    'type' => Controls_Manager::MEDIA,
                    'default' => [
                        'url' => '',
                    ],
                ]
            );
            $repeater->add_control(
                'slide_title',
                [
                    'name' => 'slide_title',
                    'label'       => __( 'Title', 'edumodo' ),
                    'type'        => Controls_Manager::TEXT,
                    'default'     => __( 'Default title text', 'edumodo' ),
                    'placeholder' => __( 'Type your title text here', 'edumodo' ),
                ]
            );
            $repeater->add_control(
                'slide_subtitle',
                [
                    'name' => 'slide_subtitle',
                    'label'       => __( 'Subtitle', 'edumodo' ),
                    'type'        => Controls_Manager::TEXT,
                    'default'     => __( 'Default title text', 'edumodo' ),
                    'placeholder' => __( 'Type your subtitle text here', 'edumodo' ),
                ]
            );
            $repeater->add_control(
                'slide_button',
                [
                    'name' => 'slide_button',
                    'label'       => __( 'Button Text', 'edumodo' ),
                    'type'        => Controls_Manager::TEXT,
                    'default'     => __( 'Default button text', 'edumodo' ),
                    'placeholder' => __( 'Type your button text here', 'edumodo' ),
                ]
            );
            $repeater->add_control(
                'slide_button_link',
                [
                    'name' => 'slide_button_link',
                    'label'       => __( 'Button Link', 'edumodo' ),
                    'type'        => Controls_Manager::TEXT,
                    'default'     => __( 'Default button link', 'edumodo' ),
                    'placeholder' => __( 'Type your button link here', 'edumodo' ),
                ]
            );
            $this->add_control(
                'sliders',
                [
                    'label'       => __( 'Repeater Options', 'edumodo' ),
                    'type' => Controls_Manager::REPEATER,
                    'fields'      => array_values( $repeater->get_controls() ),
                    'show_label'  => true,
                ]
            );
        $this->end_controls_section();

        /* style and typography and overlay color option */
        $this->start_controls_section(
            'slide_typography',
            [
                'label' => __( 'Title Typography', 'edumodo' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
            $this->add_control(
                'title_color',
                [
                    'label'     => __( 'Title Color', 'edumodo' ),
                    'type'      => Controls_Manager::COLOR,
                    'default'   => 'rgba(0, 0, 0, 1)',
                    'selectors' => [
                        '{{WRAPPER}} .slide .slide__title' => 'color: {{VALUE}};',
                    ],
                ]
            );
            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'label'     => __( 'Title Typography', 'edumodo' ),
                    'name' => 'slide_title_typography',
                    'selector' => '{{WRAPPER}} .slide .slide__title',
                    'scheme' => Scheme_Typography::TYPOGRAPHY_3,
                ]
            );
        $this->end_controls_section();

        $this->start_controls_section(
            'description_typography',
            [
                'label' => __( 'Description Typography', 'edumodo' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
            $this->add_control(
                'description_color',
                [
                    'label'     => __( 'Description Color', 'edumodo' ),
                    'type'      => Controls_Manager::COLOR,
                    'default'   => 'rgba(0, 0, 0, 1)',
                    'selectors' => [
                        '{{WRAPPER}} .slide .slide__desc' => 'color: {{VALUE}};',
                    ],
                ]
            );
            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'label'     => __( 'Description Typography', 'edumodo' ),
                    'name' => 'slide_description_typography',
                    'selector' => '{{WRAPPER}} .slide .slide__desc',
                    'scheme' => Scheme_Typography::TYPOGRAPHY_3,
                ]
            );
        $this->end_controls_section();

        $this->start_controls_section(
            'image_overlay_section',
            [
                'label' => __( 'Image Overlay', 'edumodo' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
            $this->add_control(
                'overlay_color',
                [
                    'label'     => __( 'Overlay Color', 'edumodo' ),
                    'type'      => Controls_Manager::COLOR,
                    'default'   => 'rgba(0, 0, 0, 1)',
                    'selectors' => [
                        '{{WRAPPER}} .slide .slide__img:before' => 'background-color: {{VALUE}};',
                    ],
                ]
            );
        $this->end_controls_section();


    }

    protected function render()
    {
        $slider = $this->get_settings('sliders');
        ?>
        <div class="demo-1">
            <main>
                <div class="slideshow">
                    <div class="slides">

                        <?php if($slider): $a = 0;?>
                            <?php foreach($slider as $s): ?>
                                <div class="slide <?php echo ($a == 0) ? 'slide--current': ''; ?>">
                                    <div class="slide__img" style="background-image: url(<?php echo esc_url($s['slide_image']['url']); ?>)"></div>
                                    <h2 class="slide__title"><?php echo $s['slide_title'] ?></h2>
                                    <p class="slide__desc"><?php echo $s['slide_subtitle'] ?></p>
                                    <a class="slide__link" href="<?php echo esc_url($s['slide_button_link']); ?>">
                                        <?php echo $s['slide_button'] ?>
                                    </a>
                                </div>
                                <?php $a++; endforeach; ?>
                        <?php endif; ?>


                    </div>
                    <nav class="slidenav">
                        <button class="slidenav__item slidenav__item--prev"><?php esc_html_e('Previous', 'edumodo'); ?></button>
                        <span><?php esc_html_e('/', 'edumodo'); ?></span>
                        <button class="slidenav__item slidenav__item--next"><?php esc_html_e('Next', 'edumodo'); ?></button>
                    </nav>
                </div>
            </main>
        </div>

        <?php

    }

    protected function _content_template()
    {

    }
}
