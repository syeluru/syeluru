<?php


use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Color;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor edumodo Blog
 *
 * Elementor widget for edumodo blog
 *
 * @since 1.0.0
 */
class Edumodo_Teachers_1 extends Widget_Base {

	public function get_name() {
		return 'edumodo-teacher-1';
	}

	public function get_title() {
		return __( 'Teacher 1', 'edumodo' );
	}

	public function get_icon() {
		return 'eicon-person';
	}

	public function get_categories() {
		return [ 'edumodo' ];
	}

	/**
	 * A list of scripts that the widgets is depended in
	 * @since 1.3.0
	 **/
	public function get_script_depends() {
		return [ 'edumodo-teacher-1' ];
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'section_icon',
			[
				'label' => __( 'Content', 'edumodo' ),
			]
		);

        $this->add_control(
            'posts_per_page',
            [
                'label' => __('Item to Show', 'edumodo'),
                'type' => Controls_Manager::NUMBER,
                'default' => 6,
                'min' => -1,
                'max' => 50,
                'step' => 1,
            ]
        );

        $this->add_control(
            'posts_column',
            [
                'label' => __('Column', 'edumodo'),
                'type' => Controls_Manager::SELECT,
                'default' => '4',
                'options' => [
                    '2' => __('6 Column', 'edumodo'),
                    '3' => __('4 Column', 'edumodo'),
                    '4' => __('3 Column', 'edumodo'),
                    '6' => __('2 Column', 'edumodo'),
                    '12' => __('1 Column', 'edumodo'),
                ],
            ]
        );

		$this->end_controls_section();

		$this->start_controls_section(
			'section_title',
			[
				'label' => __( 'Title', 'edumodo' ),
			]
		);

		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .teacher-person .overlay .person-info .teacher-title a',
                'scheme' => Scheme_Typography::TYPOGRAPHY_3,
            ]
        );

		$this->add_responsive_control(
			'edumodo_title_space',
			[
				'label' => __( 'Title Spacing', 'edumodo' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 5,
						'max' => 50,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .teacher-person .overlay .person-info .teacher-title' => 'margin: {{SIZE}}{{UNIT}} 0;',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'content_style',
				[
					'label' => __( 'Designation', 'edumodo' ),
				]
			);

			$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'designation_typography',
                'selector' => '{{WRAPPER}} .teacher-person .overlay .person-info .teacher-position',
                'scheme' => Scheme_Typography::TYPOGRAPHY_3,
            ]
        );

		$this->end_controls_section();

		$this->start_controls_section(
			'meta_style',
				[
					'label' => __( 'Social', 'edumodo' ),
				]
			);

		$this->add_control(
			'icon_size',
			[
				'label' => __( 'Size', 'edumodo' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 10,
						'max' => 60,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .teacher-person .overlay .person-info .social-links-teacher i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'icon_padding',
			[
				'label' => __( 'Padding', 'edumodo' ),
				'type' => Controls_Manager::SLIDER,
				'selectors' => [
					'{{WRAPPER}} .teacher-person .overlay .person-info .social-links-teacher a' => 'padding: {{SIZE}}{{UNIT}};',
				],
				'range' => [
					'em' => [
						'min' => 0,
						'max' => 30,
					],
				],
				'condition' => [
					'view!' => 'default',
				],
			]
		);

		$this->add_responsive_control(
			'title_space',
			[
				'label' => __( 'Title Spacing', 'edumodo' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 50,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .teacher-person .overlay .person-info .social-links-teacher' => 'margin: {{SIZE}}{{UNIT}} 0;',
				],
			]
		);
		$this->end_controls_section();


		$this->start_controls_section(
			'section_style',
				[
					'label' => __( 'Color Options', 'edumodo' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				]
			);

		$this->add_control(
			'content_color',
			[
				'label'     => __( 'Icon Color', 'edumodo' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#fff',
				'selectors' => [
					'{{WRAPPER}} .teacher-person .overlay .person-info .social-links-teacher a' => 'color: {{VALUE}};',
					'{{WRAPPER}} .teacher-person .overlay .person-info .social-links-teacher i' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'overlay_color',
			[
				'label'     => __( 'Overlay Color', 'edumodo' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'rgba(36, 44, 94, 0.8)',
				'selectors' => [
					'{{WRAPPER}} .teacher-person .overlay' => ' background-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();





	}

	protected function render() {
		require EDUMODO_CORE_ROOT . '/elements/teacher-1/template/view.php';
	}


}
