<?php
/**
 * Tag name == Event-1 (for Less file)
 */
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;

if (!defined('ABSPATH')) exit; // Exit if accessed directly

/**
 * tgx Schedule One
 *
 * Elementor widget for Schedule One.
 *
 * @since 1.0.0
 */
class Widget_Event_Two extends Widget_Base
{

    public function get_name()
    {
        return 'widget-event-two';
    }

    public function get_title()
    {
        return __('Event Two', 'tgx');
    }

    public function get_icon()
    {
        return ' eicon-call-to-action';
    }

    public function get_categories()
    {
        return ['edumodo'];
    }

    /**
     * A list of scripts that the widgets is depended in
     *
     * @since 1.3.0
     **/
    /*
        public function get_script_depends() {
            return [ 'imagesloaded' ];
        }
    */
    public function get_all_event_name_and_id(){
        $args = array(
            'post_type' => 'tribe_events',
        );
        $q = new WP_Query($args);
    }


    protected function _register_controls()
    {
        $args = array(
            'post_type' => 'tribe_events',
            'posts_per_page'    => -1
        );
        $query = new WP_Query($args);
        $event_names = array();
        foreach( $query->posts as $p ):
            $event_names[$p->ID] = $p->post_title;
        endforeach;

        /* slides content title subtitle button and button link */
        $this->start_controls_section(
            'section_tab',
            [
                'label' => __('Event', 'tgx'),
            ]
        );

            $this->add_control(
                'event_id',
                [
                    'label'       => __( 'Event ID', 'tgx' ),
                    'type'        => Controls_Manager::SELECT,
                    'default'     => '',
                    'options' => $event_names,
                ]
            );
            $this->add_control(
                'image_position',
                [
                    'label'       => __( 'Image Posititon', 'tgx' ),
                    'type' => Controls_Manager::SELECT,
                    'default' => 'left',
                    'options' => [
                        'left'  => __( 'Left', 'tgx' ),
                        'right' => __( 'Right', 'tgx' ),
                    ],
                ]
            );
            $this->add_responsive_control(
                'margin',
                [
                   'label' => __( 'Content Padding', 'tgx' ),
                   'type' => Controls_Manager::DIMENSIONS,
                   'size_units' => [ 'px', '%', 'em' ],
                   'selectors' => [
                           '{{WRAPPER}} .class-widget-event .event-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                   ],
                ]
            );

        $this->end_controls_section();

    }

    protected function render()
    {
        $settings = $this->get_settings();
        $event_id = $settings['event_id'];
        $image_position = $settings['image_position'];
        /**
         * Event Query
         */
        $args = array(
            'p' => $event_id,
            'post_type' => 'tribe_events',
        );
        $event_query = new WP_Query($args);

        ?>
        <div class="class-widget-event">
            <?php if($event_query->have_posts()): ?>
                <?php while($event_query->have_posts()): ?>
                    <?php $event_query->the_post(); ?>
                    <div class="row event-wrapper <?php echo ($image_position == 'right') ? 'image-on-the-right-side': ''; ?>">

                        <?php if($image_position == 'left'): ?>
                            <div class="col-md-6 event-featured-image left-side-image">
                                <div class="featured-image ">

                                    <a href="<?php the_permalink() ?>">
                                        <p class="event-time">
                                            <span >
                                                <?php echo tribe_get_start_date(null, false, 'd M Y'); ?>
                                            </span>
                                        </p>
                                        <?php if(has_post_thumbnail()): ?>
                                            <?php the_post_thumbnail('full'); ?>
                                        <?php endif; ?>
                                    </a>

                                </div>
                                <!-- end of /.featured-image -->
                            </div>
                            <!-- end of /.left-side-image -->
                        <?php endif; ?>

                        <div class="col-md-6 event-content">
                            <div class="event-content-wrapper">

                                <div class="event-title">
                                    <a href="<?php the_permalink() ?>" class="edumodo-title e-event-title">
                                        <h3 class="tgx-post-title">
                                            <?php echo wp_trim_words(get_the_title(), 10, ''); ?>
                                        </h3>
                                    </a>
                                    <p class="event-meta">
                                        <span class="event-city">
                                            <i class="fa fa-map-marker fa-fw"></i>
                                            <?php echo tribe_get_city(get_the_ID()); ?>
                                        </span>
                                        <span class="event-time">
                                            <i class="fa fa-clock-o fa-fw"></i>
                                            <?php echo tribe_get_start_date( null, false, 'g:ia' ); ?>
                                            <?php esc_html_e('to', 'tgx'); ?>
                                            <?php echo tribe_get_end_date( null, false, 'g:ia');  ?>
                                        </span>
                                    </p>
                                </div>

                                <div class="event-excerpt">
                                    <?php echo wp_trim_words(get_the_excerpt(), 20 , ''); ?>
                                </div>

                            </div>
                            <!-- end of /.event-content-wrapper -->
                        </div>
                        <!-- end of /.event-content -->

                        <?php if($image_position == 'right'): ?>
                            <div class="col-md-6 event-featured-image right-side-image">
                                <div class="featured-image ">

                                    <a href="<?php the_permalink() ?>">
                                        <p class="event-time">
                                            <span >
                                                <?php echo tribe_get_start_date(null, false, 'd M Y'); ?>
                                            </span>
                                        </p>
                                        <?php if(has_post_thumbnail()): ?>
                                            <?php the_post_thumbnail('full'); ?>
                                        <?php endif; ?>
                                    </a>

                                </div>
                                <!-- end of /.featured-image -->
                            </div>
                            <!-- end of /.right-side-image -->
                        <?php endif; ?>

                    </div>
                <?php endwhile; wp_reset_postdata();?>
            <?php endif; ?>

        </div>

        <?php

    }

    protected function _content_template()
    {

    }
}
