<?php


use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor edumodo Portfolio 1
 *
 * Elementor widget for edumodo portfolio 1
 *
 * @since 1.0.0
 */
class edumodo_testimonial_1 extends Widget_Base {

	public function get_name() {
		return 'edumodo-testimonial-1';
	}

	public function get_title() {
		return __( 'Testimonial', 'edumodo' );
	}

	public function get_icon() {
		return 'eicon-testimonial';
	}

	public function get_categories() {
		return [ 'edumodo' ];
	}

	/**
	 * A list of scripts that the widgets is depended in
	 * @since 1.3.0
	 **/
	public function get_script_depends() {
		return [ 'edumodo-testimonial-1' ];
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'section_style',
			[
				'label' => __( 'Testimonial Options', 'edumodo' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'testimonial_items',
			[
				'label'     => __( 'Testimonial Items to Show', 'edumodo' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => '3',
				'options'   => [
					'1'   => __( 'Item 1', 'edumodo' ),
					'2'   => __( 'Item 2', 'edumodo' ),
					'3'   => __( 'Item 3', 'edumodo' ),
				],
			]
		);

		$this->add_control(
			'testimoni_size',
			[
				'label' => __( 'Testimoni Font SIze', 'edumodo' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 16,
						'max' => 30,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .testimonial .testimoni-wrapper .testimony' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'text_transform',
			[
				'label'     => __( 'Name Transform', 'edumodo' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'Capitalize',
				'options'   => [
					'uppercase'   => __( 'UPPERCASE', 'edumodo' ),
					'lowercase'   => __( 'lowercase', 'edumodo' ),
					'capitalize'  => __( 'Capitalize', 'edumodo' ),
				],
				'selectors' => [
					'{{WRAPPER}} .testimonial .testimoni-wrapper .author .name' => 'text-transform: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'autoplay_enable',
			[
				'label'     => __( 'Auto Play Enable/Disable', 'edumodo' ),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => 'no',
				'true'    => __( 'True', 'edumodo' ),
				'false'   => __( 'False', 'edumodo' ),
			]
		);



		$this->end_controls_section();

		$this->start_controls_section(
			'section_testimoni',
			[
				'label' => __( 'Color Options', 'edumodo' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'testimoni_color',
			[
				'label'     => __( 'Content Color', 'edumodo' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#666',
				'selectors' => [
					'{{WRAPPER}} .edumodo-testimoni-wrapper .desc' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'name_color',
			[
				'label'     => __( 'Name Color', 'edumodo' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#182432',
				'selectors' => [
					'{{WRAPPER}} .edumodo-testimoni-wrapper .name-des .name' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'designation_color',
			[
				'label'     => __( 'Designation Color', 'edumodo' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#989898',
				'selectors' => [
					'{{WRAPPER}} .edumodo-testimoni-wrapper .name-des .designation' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'border_color',
			[
				'label'     => __( 'Border Color', 'edumodo' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ddd',
				'selectors' => [
					'{{WRAPPER}} .edumodo-testimonial .testimoni-wrapper .testimony:before' => 'color: {{VALUE}};',
					'{{WRAPPER}} .edumodo-testimonial .testimoni-wrapper .author:before' => 'border-bottom-color: {{VALUE}};',
					'{{WRAPPER}} .edumodo-testimonial .testimoni-wrapper .author' => 'border-top:1px solid {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'bg_color',
			[
				'label'     => __( 'Background Color', 'edumodo' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'transparent',
				'selectors' => [
					'{{WRAPPER}} .edumodo-testimonial .testimoni-wrapper' => 'background-color: {{VALUE}};',

				],
			]
		);

		$this->add_control(
			'hover_bg_color',
			[
				'label'     => __( 'Hover/Active Background Color', 'edumodo' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#fff',
				'selectors' => [
					'{{WRAPPER}} .edumodo-testimonial .testimoni-wrapper:hover' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .edumodo-testimonial .center .testimoni-wrapper' => 'background-color: {{VALUE}};',
				],
			]
		);

	$this->end_controls_section();
	}

	protected function render() {
		require EDUMODO_CORE_ROOT . '/elements/testimonial-1/template/view.php';
	}


}
