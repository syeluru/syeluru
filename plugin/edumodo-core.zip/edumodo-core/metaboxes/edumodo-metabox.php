<?php 

/**
* Metabox for edumodo
* @field edumodo link
* @field edumodo link
*/

/**
 * Define the metabox and field configurations.
 */
function edumodo_all_metaboxes() {

    // Start with an underscore to hide fields from custom fields list
    $prefix = '_edumodo_';


        // Teacher meta side   
        $meta_boxes = new_cmb2_box(
            array(
                'id'           => 'edumodo_tacher_side',
                'title'        => esc_html__('Teacher Details', 'edumodo'),
                'object_types' => array('teacher'), // post type
                'context'      => 'side',
                'priority'     => 'default',
                'show_names'   => true, // Show field names on the left
                'fields'       => array(
                    array(
                        'name'     => esc_html__('Teacher Image ', 'edumodo'),
                        'id'       => $prefix . 'teacher_img',
                        'type'     => 'file',
                    ),             
                    array(
                        'name'     => esc_html__('Designation', 'edumodo'),
                        'id'       => $prefix . 'teacher_designation',
                        'type'     => 'text',
                    ),             
                    array(
                        'name'     => esc_html__('Email', 'edumodo'),
                        'id'       => $prefix . 'teacher_email',
                        'type'     => 'text',
                    ),             
                    array(
                        'name'     => esc_html__('Phone', 'edumodo'),
                        'id'       => $prefix . 'teacher_phone',
                        'type'     => 'text',
                    ),             
                    array(
                        'name'     => esc_html__('Website', 'edumodo'),
                        'id'       => $prefix . 'teacher_website',
                        'type'     => 'text',
                    ),
                    
                )
            )
        );

        // Teacher meta box normal  
        $meta_boxes = new_cmb2_box(
            array(
                'id'           => 'edumodo_tacher_normal',
                'title'        => esc_html__('Teacher Social Link', 'edumodo'),
                'object_types' => array('teacher'), // post type
                'context'      => 'normal',
                'priority'     => 'high',
                'show_names'   => true, // Show field names on the left
                'fields'       => array(
                    array(
                        'name'     => esc_html__('Facebook Link', 'edumodo'),
                        'id'       => $prefix . 'teacher_facebook_link',
                        'type'     => 'text',
                        'default'  => 'https://www.facebook.com/themexpert'
                    ),
                    array(
                        'name'     => esc_html__('Twitter Link', 'edumodo'),
                        'id'       => $prefix . 'teacher_twitter_link',
                        'type'     => 'text',
                        'default'  => 'https://www.twitter.com/themexpert'
                    ),
                    array(
                        'name'     => esc_html__('Google Plus Link', 'edumodo'),
                        'id'       => $prefix . 'teacher_google_plus_link',
                        'type'     => 'text',
                        'default'  => 'https://plus.google.com/themexpert'
                    ),
                    array(
                        'name'     => esc_html__('Linkedin Link', 'edumodo'),
                        'id'       => $prefix . 'teacher_linkedin_link',
                        'type'     => 'text',
                        'default'  => 'https://www.linkedin.com/themexpert'
                    ),
                )
            )
        );



         // Teacher header image
        $course_header_image = new_cmb2_box(
            array(
                'id'           => 'teacher_head',
                'title'        => esc_html__('Teacher Header Image', 'edumodo'),
                'object_types' => array('teacher'), // post type
                'context'      => 'normal',
                'priority'     => 'high',
                'show_names'   => true, // Show field names on the left
                'fields' => array(
                     // teacher header image
                    array(
                        'name'    => esc_html__('Single teacher Header Image', 'edumodo'),
                        'id'      => $prefix . 'course_single_page_header_img',
                        'type'    => 'file',
                        'default' => '',
                    ),
                )
            )  
        );

         // Course header image
        $course_header_image = new_cmb2_box(
            array(
                'id'           => 'course_head',
                'title'        => esc_html__('Course Header Image', 'edumodo'),
                'object_types' => array('course'), // post type
                'context'      => 'normal',
                'priority'     => 'high',
                'show_names'   => true, // Show field names on the left
                'fields' => array(
                     // course header image
                    array(
                        'name'    => esc_html__('Single course Header Image', 'edumodo'),
                        'id'      => $prefix . 'course_single_page_header_img',
                        'type'    => 'file',
                        'default' => '',
                    ),
                )
            )  
        );

        // Course information
        $course_image = new_cmb2_box(
            array(
                'id'           => 'course_info',
                'title'        => esc_html__('Course Information', 'edumodo'),
                'object_types' => array('tx-course'), // post type
                'context'      => 'normal',
                'priority'     => 'high',
                'show_names'   => true, // Show field names on the left
                'fields' => array(

                    array(
                        'name'    => esc_html__('Course Start Date', 'edumodo'),
                        'id'      => $prefix . 'course_start_date',
                        'type'    => 'text_date',
                    ),

                    array(
                        'name'    => esc_html__('Course End Date', 'edumodo'),
                        'id'      => $prefix . 'course_end_date',
                        'type'    => 'text_date',
                    ),

                    array(
                        'name'    => esc_html__('Estimated Duration', 'edumodo'),
                        'id'      => $prefix . 'course_hours',
                        'type'    => 'text',
                    ),

                    array(
                        'name'    => esc_html__('Maximum Students', 'edumodo'),
                        'id'      => $prefix . 'course_students',
                        'type'    => 'text',
                    ),

                    array(
                        'name'    => esc_html__('Time', 'edumodo'),
                        'id'      => $prefix . 'course_time',
                        'type'    => 'text',
                    ),

                    array(
                        'name'    => esc_html__('Levels', 'edumodo'),
                        'id'      => $prefix . 'course_levels',
                        'type'    => 'text',
                    ),

                )
            )  
        );

        // course input options
        $course_info = new_cmb2_box(
            array(
                'id'           => 'course_price',
                'title'        => esc_html__('Course Cost', 'edumodo'),
                'object_types' => array('tx-course'), // post type
                'context'      => 'side',
                'priority'     => 'default',
                'show_names'   => true, // Show field names on the left
                'fields' => array(

                    array(
                        'id'      => $prefix . 'course_cost',
                        'type'    => 'text_medium',
                    ),
                )
            )  
        );
        

        /**
         * Choose Adventures from list
         * you may choose multiple adventure for course teacher
         */

        $dest_adv = new_cmb2_box( array(
            'id'            => $prefix . 'course_teacher',
            'title'        => esc_html__('Course Teacher', 'edumodo' ),
            'object_types' => array( 'tx-course' ), // Post type
            'context'      => 'normal',
            'priority'     => 'default',
            'show_names'   => true, // Show field names on the left
        ) );
        $dest_adv->add_field( array(
            'name'       => esc_html__( 'Title', 'edumodo' ),
            'description' => esc_html__('Write a Title', 'edumodo'),
            'id'         => $prefix . 'course_teacher_title',
            'type'       => 'text',
        ) );

        $dest_adv->add_field( array(
            'name'    => esc_html__( 'Select Teacher', 'edumodo' ),
            'desc'    => esc_html__( 'Drag teacher from left to right or click plus iocn to add', 'edumodo' ),
            'id'      => $prefix. 'select_course_teacher',
            'type'    => 'custom_attached_posts',
            'options' => array(
                'show_thumbnails' => true, // Show thumbnails on the left
                'filter_boxes'    => true, // Show a text box for filtering the results
                'query_args'      => array( 
                    'post_type' => 'teacher',
                    'posts_per_page' => 10
                    ), // override the get_posts args
            ),
        ) );

        // Testimonial options
        $testimonials = new_cmb2_box(
            array(
                'id'           => 'testimonial',
                'title'        => esc_html__('Testimonial Details', 'edumodo'),
                'object_types' => array('edumodo_testimonial'), // post type
                'context'      => 'normal',
                'priority'     => 'high',
                'show_names'   => true, // Show field names on the left
                'fields' => array(

                    array(
                        'name'     => esc_html__('Name of the Person ', 'edumodo'),
                        'id'       => $prefix . 'testimoni_name',
                        'type'     => 'text_medium',
                    ),
                    array(
                        'name'     => esc_html__('Designation', 'edumodo'),
                        'id'       => $prefix . 'testimoni_designation',
                        'type'     => 'text_medium',
                    ),
                    array(
                        'name'     => esc_html__('Testimonial', 'edumodo'),
                        'id'       => $prefix . 'testimoni_details',
                        'type'     => 'textarea',
                    ),
                )
            )
        );
  
        // Learnpress course options
        $lp_course_meta = new_cmb2_box(
            array(
                'id'           => 'edumodo_lp_course',
                'title'        => esc_html__('Course Video', 'edumodo'),
                'object_types' => array('lp_course'), // post type
                'context'      => 'side',
                'priority'     => 'default',
                'show_names'   => true, // Show field names on the left
                'fields' => array(

                     array(
                        'name' => '',
                        'desc' => 'Enter your youtube, vimeo Video embad code',
                        'id'   => 'lp_course_video',
                        'type' => 'oembed',
                    ),

                )
            )
        );
  

}

add_action( 'cmb2_admin_init', 'edumodo_all_metaboxes' );
