<?php

/**
* Metabox for blog post format
* @
*/


function edumodo_post_metabox(){


    // Start with an underscore to hide fields from custom fields list
    $prefix = '_edumodo_';

    $post_format = new_cmb2_box( array(
            'id'            => $prefix . 'post_metabox',
            'title'         => esc_html__( 'Post Format Fields', 'edumodo'),
            'object_types'  => array( 'post'), // Post type.
        ) );



        $post_format->add_field( array(
            'name'       =>  esc_html__('Upload Image', 'edumodo'),
            'desc'       =>  esc_html__('Upload your image ', 'edumodo'),
            'id'         => $prefix . 'image_format',
            'type'       => 'file',
            'attributes' => array(
                'required'               => false, // Will be required only if visible.
                'data-conditional-id'    => 'post_format',
                'data-conditional-value' => 'image',
            ),
            )
        );

        $post_format->add_field( array(
            'name'       =>  esc_html__('Upload Video', 'edumodo'),
            'desc'       =>  esc_html__('Upload your video ', 'edumodo'),
            'id'         => $prefix . 'video_format',
            'type'       => 'oembed',
            'attributes' => array(
                'required'               => false, // Will be required only if visible.
                'data-conditional-id'    => 'post_format',
                'data-conditional-value' => 'video',
            ),
            )
        );

        $post_format->add_field( array(
            'name'       =>  esc_html__('Upload Audio', 'edumodo'),
            'desc'       =>  esc_html__('Upload your audio ', 'edumodo'),
            'id'         => $prefix . 'audio_format',
            'type'       => 'oembed',
           'attributes' => array(
                'required'               => false, // Will be required only if visible.
                'data-conditional-id'    => 'post_format',
                'data-conditional-value' => 'audio',
            ),
            )
        );


        $post_format->add_field( array(
            'name'       =>  esc_html__('Upload Gallery', 'edumodo'),
            'desc'       =>  esc_html__('Upload your gallery ', 'edumodo'),
            'id'         => $prefix . 'gallery_format',
            'type'       => 'file_list',
            'attributes' => array(
                'required'               => false, // Will be required only if visible.
                'data-conditional-id'    => 'post_format',
                'data-conditional-value' => 'gallery',
            ),
            )
        );

        $post_format->add_field( array(
            'name'       =>  esc_html__('Write Link', 'edumodo'),
            'desc'       =>  esc_html__('Write your link', 'edumodo'),
            'id'         => $prefix . 'link_format',
            'type'       => 'text_medium',
            'attributes' => array(
                'required'               => false, // Will be required only if visible.
                'data-conditional-id'    => 'post_format',
                'data-conditional-value' => 'link',
            ),
            )
        );


        $post_format->add_field( array(
            'name'       =>  esc_html__('Write Quote', 'edumodo'),
            'desc'       =>  esc_html__('Write your quote', 'edumodo'),
            'id'         => $prefix . 'quote_format',
            'type'       => 'text_medium',
            'attributes' => array(
                'required'               => false, // Will be required only if visible.
                'data-conditional-id'    => 'post_format',
                'data-conditional-value' => 'quote',
            ),
            )
        );
       

    }

add_action( 'cmb2_admin_init',  'edumodo_post_metabox');